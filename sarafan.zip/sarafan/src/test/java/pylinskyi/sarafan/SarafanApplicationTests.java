package pylinskyi.sarafan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SarafanApplicationTests {

	@Test
	void contextLoads() {
	}

}
